#ifndef CONSTANTS_H
#define CONSTANTS_H

#include <QString>

const QString DIALOG_URL = "https://securechat-4276e.firebaseio.com/Dialogs/";
const QString USER_URL = "https://securechat-4276e.firebaseio.com/Users/";

#endif //CONSTANTS_H
