#include "cryptapi.h"

CryptAPI::~CryptAPI() {
}
