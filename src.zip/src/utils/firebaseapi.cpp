#include "firebaseapi.h"

FirebaseAPI::~FirebaseAPI(){};

QImage FirebaseAPI::getAvatar(const QString &username) {
    return QImage();
}
